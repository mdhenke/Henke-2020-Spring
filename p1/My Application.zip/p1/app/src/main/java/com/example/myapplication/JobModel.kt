package com.example.myapplication

data class JobModel(
    var company : String,
    var jobTitle : String,
    var description : String?
    )