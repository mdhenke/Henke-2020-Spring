package com.example.myapplication

data class UserModel(

        var email:String,
        var password:String
    )
